
from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    mobile_number = models.CharField(max_length=15)
    mac_address = models.CharField(max_length=17)

    def __str__(self):
        return self.name
