from django.apps import AppConfig


class WifiAttendanceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wifi_attendance'
