import subprocess
import json
import nmap
import openpyxl
import pyttsx3
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from .models import Student
from .forms import StudentForm

def dashboard(request):
    text_to_read = """
    Welcome to the Wifi Attendance Project Dashboard.
    This project aims to streamline the process of attendance management using WiFi network connections.
    Developed with Python and Django, the system focuses on creating a user-friendly interface and efficient attendance tracking mechanism.
    The key features of the project include:
    View and manage student details,
    Select available WiFi networks,
    Detect connected devices within a selected WiFi network,
    Highlight students with matching MAC addresses in the connected devices list,
    Generate attendance reports in Excel format.
    By leveraging WiFi technology, this system provides a modern and efficient solution to attendance management,
    reducing manual errors and saving time for administrators and instructors.
    Developed by the students of the Industrial Training Institute Bilimora under the guidance of all instructors,
    this project showcases the practical application of technical skills learned during the course.
    """
    
    engine = pyttsx3.init()
    engine.say(text_to_read)
    
    # Ensure that the engine is stopped before starting it again
    if not engine._inLoop:
        engine.runAndWait()

    return render(request, 'dashboard.html', {'text_to_read': text_to_read})

def student_list(request):
    students = Student.objects.all()
    return render(request, 'student_list.html', {'students': students})

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentForm()
    return render(request, 'add_student.html', {'form': form})

def update_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentForm(instance=student)
    return render(request, 'add_student.html', {'form': form})

def delete_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        student.delete()
        return redirect('student_list')
    return render(request, 'confirm_delete.html', {'student': student})

def wifi_list(request):
    students = Student.objects.all()
    return render(request, 'wifi_list.html', {'students': students})

def get_wifi_networks_view(request):
    networks = get_wifi_networks()
    return JsonResponse({'networks': networks})

def get_wifi_networks():
    networks = []
    try:
        result = subprocess.run(['netsh', 'wlan', 'show', 'network'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if "SSID" in line:
                ssid = line.split(":")[1].strip()
                if ssid:
                    networks.append(ssid)
    except Exception as e:
        print(f"Error fetching WiFi networks: {e}")
    return networks

def fetch_connected_devices(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        network = data.get('network')
        devices = get_connected_devices()
        return JsonResponse({'devices': devices})

def get_connected_devices():
    devices = []
    try:
        # Get the local IP address
        ipconfig_result = subprocess.run(['ipconfig'], stdout=subprocess.PIPE, text=True)
        ip_lines = ipconfig_result.stdout.split('\n')
        ipv4_line = next(line for line in ip_lines if 'IPv4 Address' in line)
        local_ip = ipv4_line.split(':')[1].strip()

        # Scan the network for connected devices using Nmap
        nm = nmap.PortScanner()
        nm.scan(hosts=f'{local_ip}/24', arguments='-sn')
        hosts_list = nm.all_hosts()

        for host in hosts_list:
            if 'mac' in nm[host]['addresses']:
                devices.append(f"IP: {host}, MAC: {nm[host]['addresses']['mac']}")
            else:
                devices.append(f"IP: {host}, MAC: Not Available")

    except Exception as e:
        print(f"Error fetching connected devices: {e}")
    return devices

def download_attendance(request):
    students = Student.objects.all()

    # Create a workbook and select the active worksheet
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Attendance"

    # Create the header row
    headers = ["Name", "Mobile No", "MAC Address", "Attendance"]
    ws.append(headers)

    # Add data rows
    connected_macs = [d.split('MAC: ')[1].strip() for d in get_connected_devices()]
    for student in students:
        attendance_status = "Present" if student.mac_address in connected_macs else "Absent"
        ws.append([student.name, student.mobile_number, student.mac_address, attendance_status])

    # Set the content type and file name for the response
    response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    response['Content-Disposition'] = 'attachment; filename=attendance.xlsx'
    wb.save(response)
    return response
