from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='home'),  # Add this line to link the homepage
    path('students/', views.student_list, name='student_list'),
    path('students/add/', views.add_student, name='add_student'),
    path('students/update/<int:pk>/', views.update_student, name='update_student'),
    path('students/delete/<int:pk>/', views.delete_student, name='delete_student'),
    path('wifis/', views.wifi_list, name='wifi_list'),
    path('get_wifi_networks/', views.get_wifi_networks_view, name='get_wifi_networks'),
    path('fetch_connected_devices/', views.fetch_connected_devices, name='fetch_connected_devices'),
    path('download_attendance/', views.download_attendance, name='download_attendance'),  # Add this line
]
